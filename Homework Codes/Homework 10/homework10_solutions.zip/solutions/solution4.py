class Team:
    def __init__(self, team_name, matches, wins, losses):
        self.team_name = team_name
        self.matches = matches
        self.wins = wins
        self.losses = losses

    def report(self):
        print("Team: ", self.team_name, ", Matches:", self.matches, ", Wins:", self.wins, ", Losses:", self.losses,
              ", Draws:",
              self.matches - (self.wins + self.losses), sep="")


if __name__ == "__main__":
    team_a = Team("Red Team", 6, 2, 2)
    team_b = Team("Blue Team", 5, 3, 2)

    team_a.report()
    team_b.report()
