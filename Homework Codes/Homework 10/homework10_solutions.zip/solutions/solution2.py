import math


class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y


class Quadrilateral:
    def __init__(self, point_a, point_b, point_c, point_d):
        self.point_a = point_a
        self.point_b = point_b
        self.point_c = point_c
        self.point_d = point_d


class Trapezoid(Quadrilateral):
    def get_area(self):
        return 0.5 * (math.sqrt(
            math.pow((self.point_a.x - self.point_b.x), 2) + math.pow((self.point_a.y - self.point_b.y),
                                                                      2)) + math.sqrt(
            math.pow((self.point_d.x - self.point_c.x), 2) + math.pow((self.point_d.y - self.point_c.y),
                                                                      2))) * (self.point_c.y - self.point_a.y)


class Parallelogram(Quadrilateral):
    def get_area(self):
        return math.sqrt(
            math.pow((self.point_a.x - self.point_b.x), 2) + math.pow((self.point_a.y - self.point_b.y), 2)) * (
                       self.point_c.y - self.point_a.y)


class Square(Quadrilateral):
    def get_area(self):
        return math.pow(
            math.sqrt(
                math.pow((self.point_a.x - self.point_b.x), 2) + math.pow((self.point_a.y - self.point_b.y), 2)),
            2)


class Rectangle(Square):
    def get_area(self):
        return math.sqrt(
            math.pow((self.point_a.x - self.point_b.x), 2) + math.pow((self.point_a.y - self.point_b.y),
                                                                      2)) * math.sqrt(
            math.pow((self.point_b.x - self.point_c.x), 2) + math.pow((self.point_b.y - self.point_c.y), 2))


if __name__ == "__main__":
    # Square
    point_a = Point(0, 0)
    point_b = Point(2, 0)
    point_c = Point(2, 2)
    point_d = Point(0, 2)
    square = Square(point_a, point_b, point_c, point_d)
    assert square.get_area() == 4

    # Rectangle
    point_a = Point(0, 0)
    point_b = Point(3, 0)
    point_c = Point(3, 2.5)
    point_d = Point(0, 2.5)
    rectangle = Rectangle(point_a, point_b, point_c, point_d)
    assert rectangle.get_area() == 7.5

    # Parallelogram
    point_a = Point(0, 0)
    point_b = Point(7, 0)
    point_c = Point(8, 4)
    point_d = Point(1, 4)
    parallelogram = Parallelogram(point_a, point_b, point_c, point_d)
    assert parallelogram.get_area() == 28.

    # Trapezoid
    point_a = Point(0, 0)
    point_b = Point(7, 0)
    point_c = Point(6, 4)
    point_d = Point(1, 4)
    trapezoid = Trapezoid(point_a, point_b, point_c, point_d)
    assert trapezoid.get_area() == 24.
