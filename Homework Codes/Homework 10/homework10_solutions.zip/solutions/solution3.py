def revert_odd_numbers_in_a_list(my_list):
    if not my_list:
        return []
    return ([] if my_list[-1] % 2 == 0 else [my_list[-1]]) + revert_odd_numbers_in_a_list(my_list[:-1])


assert revert_odd_numbers_in_a_list([]) == []
assert revert_odd_numbers_in_a_list([7]) == [7]
assert revert_odd_numbers_in_a_list([8]) == []
assert revert_odd_numbers_in_a_list([1, 2, 3, 4]) == [3, 1]
assert revert_odd_numbers_in_a_list([3, 5, 9, 2, 3, 3, 4]) == [3, 3, 9, 5, 3]
