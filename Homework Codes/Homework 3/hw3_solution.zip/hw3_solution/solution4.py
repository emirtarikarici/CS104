def print_upper_egg():
    print("  ______")
    print(" /      \\")
    print("/        \\")


def print_lower_egg():
    print("\\        /")
    print(" \\______/")


def print_stop():
    print("|  STOP  |")


def print_line_with_plus_signs():
    print("+--------+")


print_upper_egg()
print_lower_egg()
print_lower_egg()
print_line_with_plus_signs()
print_upper_egg()
print_stop()
print_lower_egg()
print_upper_egg()
print_line_with_plus_signs()
